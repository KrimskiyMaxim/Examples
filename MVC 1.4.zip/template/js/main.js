$('select').styler();
$('input[type=checkbox]').styler();

$('.table_btn_5>i').click(function () {
    $('.gray_tab').removeClass('gray_tab');
    $('.tr_sub-table').hide();
    $(this).parent().parent().parent().addClass('gray_tab');
    $(this).parent().parent().parent().next().css('display','table-row');
});

$(function () {                                      // Когда страница загрузится
    $('.bar_tab>a').each(function () {             // получаем все нужные нам ссылки
        var location = window.location.href; // получаем адрес страницы
        var link = this.href;                // получаем адрес ссылки
        if(location == link) {               // при совпадении адреса ссылки и адреса окна
            $(this).parent().attr('id', 'bar_select');  //добавляем класс
        }
    });
});