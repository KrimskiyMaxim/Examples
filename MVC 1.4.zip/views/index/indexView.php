<!DOCTYPE HTML>
<html>
<head>
    <?php require_once(ROOT . '/template/layouts/head.php'); ?>
    <link rel="stylesheet" href="../../views/index/css/main.css">
</head>
<body>
<header>
    шапка
</header>
<article>
index
</article>
<footer>
    футер
</footer>
</body>
<?php require_once(ROOT . '/template/layouts/add_scripts.php'); ?>
</html>