<?php

	return $routes = array(
	   'login' => 'login/index/no_session',
	   '' => 'index/index/no_session'
	);

