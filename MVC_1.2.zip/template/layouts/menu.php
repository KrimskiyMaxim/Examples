<div id="bar_top">
    <div id="bar_logo"><a href="#"><img src="../../template/img/logo.svg"></a></div>
    <div id="bar_top_item">
        <div id="bar_top_left">
            <div class="jc_fs col">
                <div class="row"><p id="bar_user_name">Vitalii Bezrodnyi</p><p id="bar_user_vip">vip</p></div>
                <div><p id="bar_user_nickName">NickName</p></div>
            </div>
            <i class="fa fa-angle-right mr10 ml10" aria-hidden="true"></i>
            <select>
                <option>Выбор аккаунта</option>
                <option>Выбор Выбор Выбор аккаунта</option>
                <option>Выбор</option>
                <option>Выбор аккаунта</option>
            </select>
            <div id="bar_balance" class="col ml40">
                <p>Баланс: <span>$132,92</span></p>
                <a>Пополнить баланс</a>
            </div>
            <div id="bar_payments" class="row ml40 ">
                <p>ПЛАТЕЖИ К ОПЛАТЕ: <span>$132,92</span></p>
                <div class="ml10"><p>Оплатить</p></div>
            </div>
        </div>
        <div id="bar_top_right">
<!--                            <div class="row" id="add_order">-->
<!--                                <input class="btn_w" type="button" value="Добавить заказ" >-->
<!--                            </div>-->
<!--                            <div id="bar_social_icon">-->
<!--                                <i class="fa fa-facebook" aria-hidden="true"></i>-->
<!--                                <i class="fa fa-vk" aria-hidden="true"></i>-->
<!--                                <i class="fa fa-linkedin" aria-hidden="true"></i>-->
<!--                                <i class="fa fa-instagram" aria-hidden="true"></i>-->
<!--                            </div>-->
        </div>
    </div>
</div>
<div id="bar_left">
    <div class="bar_tab"><a href="/"><img src="../../template/img/menu/report.svg"><p>сводка</p></a></div>
    <div class="bar_tab"><a href="stock"><img src="../../template/img/menu/stock.svg"><p>склад</p></a></div>
    <div class="bar_tab"><a href="processing"><img src="../../template/img/menu/processing.svg"><p>в обработке</p></a></div>
    <div class="bar_tab"><a href="delivery"><img src="../../template/img/menu/delivery.svg"><p>На доставке</p></a></div>
    <div class="bar_tab"><a><img src="../../template/img/menu/receiving.svg"><p>Полученные</p></a></div>
    <div class="bar_tab"><a><img src="../../template/img/menu/receivers.svg"><p>Получатели</p></a></div>
    <div class="bar_tab"><a><img src="../../template/img/menu/bills.svg"><p>Счета</p></a></div>
    <div class="bar_tab"><a><img src="../../template/img/menu/balance.svg"><p>Баланс</p></a></div>
    <div class="bar_tab"><a><img src="../../template/img/menu/personal.svg"><p>Личные данные</p></a></div>
    <div class="bar_tab" id="bar_logout"><a><img src="../../template/img/menu/logout.svg"><p>Выход</p></a></div>
</div>