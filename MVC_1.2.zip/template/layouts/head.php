<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link type="text/css" rel="stylesheet" href="template/css/main.css">
<link type="text/css" rel="stylesheet" href="template/css/header.css">
<link type="text/css" rel="stylesheet" href="template/css/footer.css">
<link type="text/css" rel="stylesheet" href="template/css/font-awesome.css">