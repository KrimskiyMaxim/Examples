<?php
    return $routes = array(
        '' => 'index/index'
	);

