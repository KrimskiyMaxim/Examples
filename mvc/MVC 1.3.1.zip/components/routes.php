<?php

	return $routes = array(
	   'login' => 'login/index/none',
	   'ajax' => 'ajax/index/none',
	   '' => 'index/index/none'
	);

