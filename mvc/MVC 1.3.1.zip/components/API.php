<?php
class esb
{
    static function esb_request($param) {
        $config = require(ROOT.'/components/config.php');
        $addr = 'http://'.$config['addr_esb']; //global
        $service = 'spAPI';
        return file_get_contents($addr.'/'.$service.'/'.$param);
    }
    static function esb_response_parse($data){
        $response = new SimpleXMLElement($data);
        return json_decode(json_encode($response), true);
    }
    static function esb_one_or_more($response) {
        if((!isset($response['Entry']['0']))){
            if($response == array()) {
                return null;
            } else {
                $var['0'] = $response['Entry'];
                return $var;
            }
        } else {
            return $response['Entry'];
        }
    }
    static function esb_all_in_one($param) {
        $request = self::esb_request($param);
        $response = self::esb_response_parse($request);
        return self::esb_one_or_more($response);
    }


    /*GET*/
    static function get_order_for_post_2($user_id) {
        $str_param = __FUNCTION__."?user_id=$user_id";
        return (self::esb_all_in_one($str_param));
    }
    static function get_service_by_order_for_site($order_id) {
        $str_param = __FUNCTION__."?order_id=$order_id";
        return (self::esb_all_in_one($str_param));
    }

    /*PUT*/
    static function put_order_processing_done($order_id, $done) {
        $str_param = __FUNCTION__."?order_id=$order_id&done=$done";
        return (self::esb_request($str_param));
    }
    static function put_status_order_service($status_id, $service_id, $order_id) {
        $str_param = __FUNCTION__."?status_id=$status_id&service_id=$service_id&order_id=$order_id";
        return (self::esb_request($str_param));
    }
    static function put_link_for_order_service($link, $order_id, $service_id) {
        $str_param = __FUNCTION__."?link=$link&order_id=$order_id&service_id=$service_id";
        return (self::esb_request($str_param));
    }
}