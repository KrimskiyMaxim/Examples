<?php
class LoginController {
    function actionIndex() {
        require_once(ROOT . '/views/'.RUNNING_VIEW.'/indexView.php');
    }
}