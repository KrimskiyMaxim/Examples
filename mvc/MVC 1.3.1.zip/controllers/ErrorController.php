<?php
class ErrorController {
    function page404Index() {
        require_once(ROOT . '/views/error404/indexView.php');
    }
}