<link rel="stylesheet" type="text/css" href="views_layouts/footer/css/main.css">
footer