<!DOCTYPE HTML>
<html>
<head>
    <title>Страница не найдена</title>
    <?php require_once(ROOT . '/views_layouts/head/layout.php'); ?>
    <link rel="stylesheet" href="views/error404/css/main.css<?='?'.LAST_MODIFIED?>">
    <script>
        setInterval(function () {
            var sec = $('#block_timer').html();
            $('#block_timer').html(sec-1);
            if(sec == 1){
                window.location = '/';
            }
        }, 1000);
    </script>
</head>
<body>
<article class="col jc_sa">
    <div class="w100 row jc_c" style="font-size: 200px"><i class="fa fa-magic"></i></div>
    <div class="col w100 jc_c">
        <div class="ta_c mb20" style="font-size: 75px"><p>404</p></div>
        <div class="ta_c" style="font-size: 55px">Страница не найдена</div>
        <div class="ta_c">Перенаправление через <span id="block_timer">5</span></div>
    </div>
</article>
</body>
<?php require_once(ROOT . '/views_layouts/add_scripts/layout.php'); ?>
</html>