<!DOCTYPE HTML>
<html>
<head>
    <?php require_once(ROOT . '/views_layouts/head/layout.php'); ?>
</head>
<body>
<header>
    <?php require_once(ROOT . '/views_layouts/header/layout.php'); ?>
</header>
<article>
    login
</article>
<footer>
    <?php require_once(ROOT . '/views_layouts/footer/layout.php'); ?>
</footer>
</body>
<?php require_once(ROOT . '/views_layouts/add_scripts/layout.php'); ?>
</html>