<?php
namespace kernel\system;

class Controller {
    public $added_styles;
    public $added_scripts;

    public function view($path, $data = null){
        $_added_styles = $this->added_styles;
        $_added_scripts = $this->added_scripts;
        $_styles = $this->ob_include(TEMPLATE.'/layouts/styles.tpl');
        $_scripts = $this->ob_include(TEMPLATE.'/layouts/scripts.tpl');


        $_head = TEMPLATE.'/layouts/head.tpl';
        $_header = TEMPLATE.'/layouts/header.tpl';
        $_footer = TEMPLATE.'/layouts/footer.tpl';


        $_content = TEMPLATE.'/'.$path.'.tpl';

        if(isset($data)) {
            foreach ($data as $key => $item){
                ${$key} = $item;
            }
        }

        include $_head;
        include $_header;
        include $_content;
        include $_footer;
    }
    public function ob_include($path, $data = null) {
        if(isset($data)) {
            foreach ($data as $key => $item){
                ${$key} = $item;
            }
        }

        ob_start();
        include $path;
        $var = ob_get_contents();
        ob_end_clean();
        return $var;
    }
    public function addScript($script) {
        if(empty($this->added_scripts)){$this->added_scripts = '';}
        $this->added_scripts = $this->added_scripts."<script src='".'//'.DOMAIN.'/views/javascript/'.$script.'.js?'.LAST_MODIFICATION."'></script> \n";
    }
    public function addStyle($style) {
        if(empty($this->added_styles)){$this->added_styles = '';}
        $this->added_styles = $this->added_styles."<link rel='stylesheet' href='".'//'.DOMAIN.'/views/stylesheet/'.$style.'.css?'.LAST_MODIFICATION."'> \n";
    }

}