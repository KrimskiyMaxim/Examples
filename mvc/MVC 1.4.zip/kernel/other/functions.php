<?php

    function dd($array)
    {
        echo('<pre>');
        print_r($array);
        die;
    }
