<?php

	return $routes = array(
	   'about' => ['about', 'index', 'none'],
	   'login' => ['login', 'index', 'none'],
	   '' => ['index', 'index', 'none']
	);

