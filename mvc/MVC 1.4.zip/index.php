<?php
require_once ('kernel/system/main.php');

$begin = new Router;
$begin->start();
