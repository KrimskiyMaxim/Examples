<?php
require_once 'components/main.php';
class AjaxController {
    function actionIndex() {

    }
}