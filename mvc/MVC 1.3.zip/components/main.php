<?php
$path = str_replace('index.php', '', (string) $_SERVER['SCRIPT_FILENAME']);
$path = str_replace('components','',dirname(__FILE__));
$path = substr($path,0,-1);
define('ROOT', $path);


require_once ROOT.'/components/config.php';
if($config['session_on']) session_start();
if($config['buffer_on']) ob_start();
if($config['show_errors']) {ini_set("display_errors",1); error_reporting(E_ALL);}

require(ROOT.'/components/Router.php');

/////////////////////////////////////////////////////////////////////////////////////////////////////
define('LAST_MODIFIED', $config['last_mod']); // время последнего изменения страницы//
/////////////////////////////////////////////////////////////////////////////////////////////////////
//
//$LastModified = gmdate("D, d M Y H:i:s \G\M\T", LAST_MODIFIED);
//$IfModifiedSince = false;
//if (isset($_ENV['HTTP_IF_MODIFIED_SINCE']))
//    $IfModifiedSince = strtotime(substr($_ENV['HTTP_IF_MODIFIED_SINCE'], 5));
//if (isset($_SERVER['HTTP_IF_MODIFIED_SINCE']))
//    $IfModifiedSince = strtotime(substr($_SERVER['HTTP_IF_MODIFIED_SINCE'], 5));
//if ($IfModifiedSince && $IfModifiedSince >= LAST_MODIFIED) {
//    header($_SERVER['SERVER_PROTOCOL'] . ' 304 Not Modified');
//    exit;
//}
//
//header('Last-Modified: '. $LastModified);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////


