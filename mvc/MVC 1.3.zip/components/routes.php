<?php

	return $routes = array(
	   'login' => 'login/index/no_session',
	   'ajax' => 'ajax/index/none',
	   '' => 'index/index/session'
	);

