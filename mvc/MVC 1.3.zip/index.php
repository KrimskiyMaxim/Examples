<?php
require_once ('components/main.php');

$begin = new Router;
$begin->start();
