<!DOCTYPE HTML>
<html>
<head>
    <?php require_once(ROOT . '/views_layouts/head/layout.php'); ?>
</head>
<body>
<article>
404
</article>
</body>
<?php require_once(ROOT . '/views_layouts/add_scripts/layout.php'); ?>
</html>