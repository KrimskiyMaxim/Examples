<!DOCTYPE HTML>
<html>
<head>
    <?php require_once(ROOT . '/views_layouts/head/layout.php'); ?>
</head>
<body>
<header>
    шапка
</header>
<article>
<form id="asd" name="asd">
    <input name="asd0" value="asd0">
    <input name="asd1" value="asd1">
    <input name="asd2" value="asd2">
</form>
</article>
<footer>
    футер
</footer>
</body>
<?php require_once(ROOT . '/views_layouts/add_scripts/layout.php'); ?>
</html>