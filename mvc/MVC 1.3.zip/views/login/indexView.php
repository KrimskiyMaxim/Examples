<!DOCTYPE HTML>
<html>
<head>
    <?php require_once(ROOT . '/views_layouts/head/layout.php'); ?>
</head>
<body>
<header>
    шапка
</header>
<article>
login
</article>
<footer>
    футер
</footer>
</body>
<?php require_once(ROOT . '/views_layouts/add_scripts/layout.php'); ?>
</html>