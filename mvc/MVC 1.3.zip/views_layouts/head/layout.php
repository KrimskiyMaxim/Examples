<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link type="text/css" rel="stylesheet" href="template/css/general.css<?='?'.LAST_MODIFIED?>">
<link type="text/css" rel="stylesheet" href="template/css/header.css<?='?'.LAST_MODIFIED?>">
<link type="text/css" rel="stylesheet" href="template/css/footer.css<?='?'.LAST_MODIFIED?>">
<link type="text/css" rel="stylesheet" href="template/css/font-awesome.css">


<link rel="stylesheet" href="views/<?=RUNNING_VIEW?>/css/main.css<?='?'.LAST_MODIFIED?>">
