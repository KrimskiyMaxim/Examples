<script src="template/js/jquery-3.2.1.min.js"></script>
<script src="template/js/general.js<?='?'.LAST_MODIFIED?>"></script>

<script src="views/<?=RUNNING_VIEW?>/js/main.js<?='?'.LAST_MODIFIED?>"></script>