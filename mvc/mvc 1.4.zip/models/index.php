<?php
namespace models;

use kernel\system\Model;

class index extends Model {
    function index() {

    }
}