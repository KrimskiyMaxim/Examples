<!DOCTYPE HTML>
<html>
<head>
    <?php require_once(ROOT . '/template/layouts/head.php'); ?>
</head>
<body>
<article>
404
</article>
</body>
<?php require_once(ROOT . '/template/layouts/add_scripts.php'); ?>
</html>