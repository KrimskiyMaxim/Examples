<?php

	return $routes = array(
	   'login' => 'login/index/no_session',
	   '' => 'report/index/session'
	);

